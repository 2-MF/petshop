package petshop;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class PetShop {

    private Scanner sc;

    public PetShop(Scanner sc) {
        this.sc = sc;
    }

    public void registrarFuncionario() {

        System.out.println("=== REGISTRAR FUNCIONARIO ===");

        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Apellido: ");
        String apellido = sc.nextLine();

        System.out.print("Cedula: ");
        String cedula = sc.nextLine();

        System.out.print("Telefono: ");
        String telefono = sc.nextLine();

        System.out.print("Legajo: ");
        String legajo = sc.nextLine();

        System.out.println("Rol:");
        System.out.println("1. Administrador");
        System.out.println("2. Funcionario comun");
        System.out.println("3. Banador");
        System.out.print("Opcion: ");

        int opcion = Integer.parseInt(sc.nextLine());

        String rol;

        if (opcion == 1) {
            rol = "administrador";
        } else if (opcion == 2) {
            rol = "funcionario comun";
        } else if (opcion == 3) {
            rol = "banador";
        } else {
            System.out.println("Opcion invalida.");
            return;
        }

        String sql = "INSERT INTO funcionario " +
                "(nombre, apellido, cedula, telefono, legajo, rol) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try {

            Connection con = Conexion.conectar();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, nombre);
            ps.setString(2, apellido);
            ps.setString(3, cedula);
            ps.setString(4, telefono);
            ps.setString(5, legajo);
            ps.setString(6, rol);

            ps.executeUpdate();

            System.out.println("Funcionario registrado correctamente.");

            ps.close();
            con.close();

        } catch (SQLException e) {
            System.out.println("Error al registrar funcionario.");
        }
    }

    public void registrarCliente() {

        System.out.println("=== REGISTRAR CLIENTE ===");

        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Apellido: ");
        String apellido = sc.nextLine();

        System.out.print("Cedula: ");
        String cedula = sc.nextLine();

        System.out.print("Telefono: ");
        String telefono = sc.nextLine();

        String comprobar = "SELECT id FROM cliente WHERE cedula = ?";

        try {

            Connection con = Conexion.conectar();

            PreparedStatement psComprobar = con.prepareStatement(comprobar);

            psComprobar.setString(1, cedula);

            ResultSet rs = psComprobar.executeQuery();

            if (rs.next()) {

                System.out.println("Ya existe un cliente con esa cedula.");

                rs.close();
                psComprobar.close();
                con.close();

                return;
            }

            rs.close();
            psComprobar.close();

            String sql = "INSERT INTO cliente " +
                    "(nombre, apellido, cedula, telefono) " +
                    "VALUES (?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, nombre);
            ps.setString(2, apellido);
            ps.setString(3, cedula);
            ps.setString(4, telefono);

            ps.executeUpdate();

            System.out.println("Cliente registrado correctamente.");

            ps.close();
            con.close();

        } catch (SQLException e) {
            System.out.println("Error al registrar cliente.");
        }
    }

    public void registrarMascota() {

        System.out.println("=== REGISTRAR MASCOTA ===");

        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Especie: ");
        String especie = sc.nextLine();

        System.out.print("Raza: ");
        String raza = sc.nextLine();

        System.out.print("ID del cliente dueño: ");
        int idCliente = Integer.parseInt(sc.nextLine());

        String comprobar = "SELECT id FROM cliente WHERE id = ?";

        try {

            Connection con = Conexion.conectar();

            PreparedStatement psComprobar = con.prepareStatement(comprobar);

            psComprobar.setInt(1, idCliente);

            ResultSet rs = psComprobar.executeQuery();

            if (!rs.next()) {

                System.out.println("No existe ese cliente.");

                rs.close();
                psComprobar.close();
                con.close();

                return;
            }

            rs.close();
            psComprobar.close();

            String sql = "INSERT INTO mascota " +
                    "(nombre, especie, raza, id_cliente) " +
                    "VALUES (?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, nombre);
            ps.setString(2, especie);
            ps.setString(3, raza);
            ps.setInt(4, idCliente);

            ps.executeUpdate();

            System.out.println("Mascota registrada correctamente.");

            ps.close();
            con.close();

        } catch (SQLException e) {
            System.out.println("Error al registrar mascota.");
        }
    }

    public void registrarConsulta() {

        System.out.println("=== REGISTRAR CONSULTA ===");

        System.out.print("ID del cliente: ");
        int idCliente = Integer.parseInt(sc.nextLine());

        System.out.print("ID del funcionario: ");
        int idFuncionario = Integer.parseInt(sc.nextLine());

        System.out.print("Descripcion: ");
        String descripcion = sc.nextLine();

        String comprobar = "SELECT id FROM cliente WHERE id = ?";

        try {

            Connection con = Conexion.conectar();

            PreparedStatement psComprobar = con.prepareStatement(comprobar);

            psComprobar.setInt(1, idCliente);

            ResultSet rs = psComprobar.executeQuery();

            if (!rs.next()) {

                System.out.println("No existe ese cliente.");

                rs.close();
                psComprobar.close();
                con.close();

                return;
            }

            rs.close();
            psComprobar.close();

            String sql = "INSERT INTO consulta " +
                    "(id_cliente, id_funcionario, descripcion, fecha) " +
                    "VALUES (?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, idCliente);
            ps.setInt(2, idFuncionario);
            ps.setString(3, descripcion);
            ps.setDate(4, java.sql.Date.valueOf(LocalDate.now()));

            ps.executeUpdate();

            System.out.println("Consulta registrada correctamente.");

            ps.close();
            con.close();

        } catch (SQLException e) {
            System.out.println("Error al registrar consulta.");
        }
    }

    public void registrarTurno() {

        System.out.println("=== REGISTRAR TURNO ===");

        System.out.print("ID de la mascota: ");
        int idMascota = Integer.parseInt(sc.nextLine());

        String comprobar = "SELECT id FROM mascota WHERE id = ?";

        try {

            Connection con = Conexion.conectar();

            PreparedStatement psComprobar = con.prepareStatement(comprobar);

            psComprobar.setInt(1, idMascota);

            ResultSet rs = psComprobar.executeQuery();

            if (!rs.next()) {

                System.out.println("No existe esa mascota.");

                rs.close();
                psComprobar.close();
                con.close();

                return;
            }

            rs.close();
            psComprobar.close();

            System.out.println("Tipo de servicio:");
            System.out.println("1. Corte de pelo");
            System.out.println("2. Bano");
            System.out.println("3. Corte y bano");

            System.out.print("Opcion: ");

            int opcion = Integer.parseInt(sc.nextLine());

            String tipoServicio;

            if (opcion == 1) {
                tipoServicio = "corte de pelo";
            } else if (opcion == 2) {
                tipoServicio = "bano";
            } else if (opcion == 3) {
                tipoServicio = "corte y bano";
            } else {
                System.out.println("Opcion invalida.");
                con.close();
                return;
            }

            System.out.print("Fecha (AAAA-MM-DD): ");
            LocalDate fecha = LocalDate.parse(sc.nextLine());

            System.out.print("Hora (HH:MM): ");
            LocalTime hora = LocalTime.parse(sc.nextLine());

            String contar = "SELECT COUNT(*) FROM turno WHERE fecha = ?";

            PreparedStatement psContar = con.prepareStatement(contar);

            psContar.setDate(1, java.sql.Date.valueOf(fecha));

            ResultSet rsContar = psContar.executeQuery();

            rsContar.next();

            int cantidad = rsContar.getInt(1);

            rsContar.close();
            psContar.close();

            if (cantidad >= 10) {

                System.out.println("No se pueden registrar mas de 10 turnos para ese dia.");

                con.close();

                return;
            }

            String sql = "INSERT INTO turno " +
                    "(id_mascota, tipo_servicio, fecha, hora, estado, id_banador) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, idMascota);
            ps.setString(2, tipoServicio);
            ps.setDate(3, java.sql.Date.valueOf(fecha));
            ps.setTime(4, java.sql.Time.valueOf(hora));
            ps.setString(5, "pendiente");
            ps.setNull(6, java.sql.Types.INTEGER);

            ps.executeUpdate();

            System.out.println("Turno registrado correctamente.");

            ps.close();
            con.close();

        } catch (SQLException e) {
            System.out.println("Error al registrar turno.");
        }
    }

    public void mostrarAgenda() {

        System.out.println("=== AGENDA ===");

        String sql = "SELECT turno.id, mascota.nombre, turno.tipo_servicio, " +
                "turno.fecha, turno.hora, turno.estado " +
                "FROM turno " +
                "INNER JOIN mascota ON turno.id_mascota = mascota.id " +
                "ORDER BY turno.fecha, turno.hora";

        try {

            Connection con = Conexion.conectar();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                System.out.println("-------------------------");
                System.out.println("Turno: " + rs.getInt(1));
                System.out.println("Mascota: " + rs.getString(2));
                System.out.println("Servicio: " + rs.getString(3));
                System.out.println("Fecha: " + rs.getDate(4));
                System.out.println("Hora: " + rs.getTime(5));
                System.out.println("Estado: " + rs.getString(6));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (SQLException e) {
            System.out.println("Error al mostrar agenda.");
        }
    }

    public void realizarServicio() {

        System.out.println("=== REALIZAR SERVICIO ===");

        System.out.print("ID del turno: ");
        int idTurno = Integer.parseInt(sc.nextLine());

        String comprobar = "SELECT id FROM turno WHERE id = ?";

        try {

            Connection con = Conexion.conectar();

            PreparedStatement psComprobar = con.prepareStatement(comprobar);

            psComprobar.setInt(1, idTurno);

            ResultSet rs = psComprobar.executeQuery();

            if (!rs.next()) {

                System.out.println("No existe ese turno.");

                rs.close();
                psComprobar.close();
                con.close();

                return;
            }

            rs.close();
            psComprobar.close();

            String sql = "UPDATE turno SET estado = 'realizado' WHERE id = ?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, idTurno);

            ps.executeUpdate();

            System.out.println("Servicio realizado correctamente.");

            ps.close();
            con.close();

        } catch (SQLException e) {
            System.out.println("Error al realizar servicio.");
        }
    }
}
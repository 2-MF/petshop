package petshop;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        PetShop petShop = new PetShop(sc);

        System.out.println("=== PETSHOP ===");
        System.out.println("Seleccione el tipo de funcionario:");
        System.out.println("1. Administrador");
        System.out.println("2. Funcionario comun");
        System.out.println("3. Banador");
        System.out.print("Opcion: ");

        int tipo = Integer.parseInt(sc.nextLine());

        int opcion;

        do {

            System.out.println();
            System.out.println("==============================");
            System.out.println("          PETSHOP");
            System.out.println("==============================");

            if (tipo == 1) {

                System.out.println("1. Registrar funcionario");
                System.out.println("2. Registrar cliente");
                System.out.println("3. Registrar mascota");
                System.out.println("4. Registrar consulta");
                System.out.println("5. Registrar turno");
                System.out.println("6. Mostrar agenda");
                System.out.println("7. Realizar servicio");
                System.out.println("0. Salir");

            } else if (tipo == 2) {

                System.out.println("1. Registrar cliente");
                System.out.println("2. Registrar consulta");
                System.out.println("0. Salir");

            } else if (tipo == 3) {

                System.out.println("1. Mostrar agenda");
                System.out.println("2. Realizar servicio");
                System.out.println("0. Salir");

            } else {

                System.out.println("Tipo de funcionario invalido.");
                break;
            }

            System.out.print("Seleccione una opcion: ");
            opcion = Integer.parseInt(sc.nextLine());

            if (tipo == 1) {

                switch (opcion) {

                    case 1:
                        petShop.registrarFuncionario();
                        break;

                    case 2:
                        petShop.registrarCliente();
                        break;

                    case 3:
                        petShop.registrarMascota();
                        break;

                    case 4:
                        petShop.registrarConsulta();
                        break;

                    case 5:
                        petShop.registrarTurno();
                        break;

                    case 6:
                        petShop.mostrarAgenda();
                        break;

                    case 7:
                        petShop.realizarServicio();
                        break;

                    case 0:
                        System.out.println("Saliendo...");
                        break;

                    default:
                        System.out.println("Opcion invalida.");
                }

            } else if (tipo == 2) {

                switch (opcion) {

                    case 1:
                        petShop.registrarCliente();
                        break;

                    case 2:
                        petShop.registrarConsulta();
                        break;

                    case 0:
                        System.out.println("Saliendo...");
                        break;

                    default:
                        System.out.println("Opcion invalida.");
                }

            } else if (tipo == 3) {

                switch (opcion) {

                    case 1:
                        petShop.mostrarAgenda();
                        break;

                    case 2:
                        petShop.realizarServicio();
                        break;

                    case 0:
                        System.out.println("Saliendo...");
                        break;

                    default:
                        System.out.println("Opcion invalida.");
                }
            }

        } while (opcion != 0);

        sc.close();
    }
}
package petshop;

import java.time.LocalDate;
import java.time.LocalTime;

public class Turno {

    private int id;
    private int idMascota;
    private String tipoServicio;
    private LocalDate fecha;
    private LocalTime hora;
    private String estado;
    private int idBanador;

    public Turno() {
    }

    public Turno(int idMascota, String tipoServicio, LocalDate fecha,
                 LocalTime hora, String estado, int idBanador) {
        this.idMascota = idMascota;
        this.tipoServicio = tipoServicio;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
        this.idBanador = idBanador;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdMascota() {
        return idMascota;
    }

    public void setIdMascota(int idMascota) {
        this.idMascota = idMascota;
    }

    public String getTipoServicio() {
        return tipoServicio;
    }

    public void setTipoServicio(String tipoServicio) {
        this.tipoServicio = tipoServicio;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getIdBanador() {
        return idBanador;
    }

    public void setIdBanador(int idBanador) {
        this.idBanador = idBanador;
    }
}
package petshop;

import java.time.LocalDate;

public class Consulta {

    private int id;
    private int idCliente;
    private int idFuncionario;
    private String descripcion;
    private LocalDate fecha;

    public Consulta() {
    }

    public Consulta(int idCliente, int idFuncionario,
                    String descripcion, LocalDate fecha) {
        this.idCliente = idCliente;
        this.idFuncionario = idFuncionario;
        this.descripcion = descripcion;
        this.fecha = fecha;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
}